# Common includes

```sh
./linker
```
