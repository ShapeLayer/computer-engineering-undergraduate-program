#include "face_tracker.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>

struct FaceTracker::Impl
{
  cv::VideoCapture cap;
  cv::CascadeClassifier face;
  cv::CascadeClassifier eye;
  cv::CascadeClassifier mouth;
  cv::dnn::Net faceNet;
  bool useDnn = false;
  bool debug = false;
  FaceState smoothed;
  cv::Rect lastLeftEye;
  cv::Rect lastRightEye;
  cv::Rect lastMouth;
  int missingEyesFrames = 0;
  int missingMouthFrames = 0;
};

FaceTracker::FaceTracker() = default;

FaceTracker::~FaceTracker()
{
  delete impl_;
}

void FaceTracker::SetDebug(bool enable)
{
  if (!impl_)
    return;
  impl_->debug = enable;
}

static std::string joinPath(const std::string &base, const std::string &file)
{
  if (base.empty())
  {
    return file;
  }
  const char last = base.back();
  if (last == '/' || last == '\\')
  {
    return base + file;
  }
  return base + "/" + file;
}

bool FaceTracker::EnsureCascades(const std::string &cascadeDir)
{
  const std::string facePath = joinPath(cascadeDir, "haarcascade_frontalface_default.xml");
  const std::string eyePath = joinPath(cascadeDir, "haarcascade_eye_tree_eyeglasses.xml");
  const std::string mouthPath = joinPath(cascadeDir, "haarcascade_smile.xml");

  if (!impl_->face.load(facePath))
    return false;
  if (!impl_->eye.load(eyePath))
  {
    const std::string eyeFallback = joinPath(cascadeDir, "haarcascade_eye.xml");
    if (!impl_->eye.load(eyeFallback))
      return false;
  }
  if (!impl_->mouth.load(mouthPath))
    return false;
  return true;
}

bool FaceTracker::Initialize(const std::string &cascadeDir, int cameraIndex,
                             const std::string &dnnProtoPath,
                             const std::string &dnnModelPath)
{
  delete impl_;
  impl_ = new Impl();
  impl_->smoothed = FaceState();
  impl_->missingEyesFrames = 0;
  impl_->missingMouthFrames = 0;
  impl_->lastLeftEye = cv::Rect();
  impl_->lastRightEye = cv::Rect();
  impl_->lastMouth = cv::Rect();

  if (!EnsureCascades(cascadeDir))
  {
    return false;
  }

  if (!dnnProtoPath.empty() && !dnnModelPath.empty())
  {
    try
    {
      impl_->faceNet = cv::dnn::readNetFromCaffe(dnnProtoPath, dnnModelPath);
      impl_->useDnn = !impl_->faceNet.empty();
    }
    catch (...)
    {
      impl_->useDnn = false;
    }
  }

  impl_->cap.open(cameraIndex);
  if (!impl_->cap.isOpened())
  {
    return false;
  }
  impl_->cap.set(cv::CAP_PROP_FRAME_WIDTH, 1280);
  impl_->cap.set(cv::CAP_PROP_FRAME_HEIGHT, 720);
  return true;
}

float FaceTracker::Smooth(float prev, float next, double dtSeconds, float sharpness) const
{
  const float alpha = 1.0f - std::exp(-sharpness * static_cast<float>(dtSeconds));
  return prev + (next - prev) * alpha;
}

static float clampFloat(float v, float lo, float hi)
{
  return std::max(lo, std::min(hi, v));
}

bool FaceTracker::Update(double dtSeconds, FaceState &outState)
{
  if (!impl_)
  {
    return false;
  }

  cv::Mat frame;
  if (!impl_->cap.read(frame))
  {
    outState = impl_->smoothed;
    return false;
  }

  cv::Mat gray;
  cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
  cv::equalizeHist(gray, gray);

  std::vector<cv::Rect> faces;
  impl_->face.detectMultiScale(gray, faces, 1.1, 4, 0, cv::Size(120, 120));

  FaceState current;
  cv::Rect bestRect;
  std::vector<cv::Rect> eyes;
  std::vector<cv::Rect> mouths;
  if (faces.empty())
  {
    current.hasFace = false;
  }
  else
  {
    current.hasFace = true;
    bestRect = *std::max_element(faces.begin(), faces.end(),
                                 [](const cv::Rect &a, const cv::Rect &b)
                                 { return a.area() < b.area(); });

    const int expandTop = static_cast<int>(bestRect.height * 0.05f);
    const int expandBottom = static_cast<int>(bestRect.height * 0.30f);
    int newY = std::max(0, bestRect.y - expandTop);
    int newH = bestRect.height + expandTop + expandBottom;
    if (newY + newH > frame.rows)
      newH = frame.rows - newY;
    bestRect.y = newY;
    bestRect.height = std::max(1, newH);

    const float cx = bestRect.x + bestRect.width * 0.5f;
    const float cy = bestRect.y + bestRect.height * 0.5f;
    const float nx = (cx / frame.cols) * 2.0f - 1.0f;
    const float ny = (cy / frame.rows) * 2.0f - 1.0f;
    current.angleY = clampFloat(nx * 30.0f, -30.0f, 30.0f);
    current.angleX = clampFloat(-ny * 30.0f, -30.0f, 30.0f);
    current.angleZ = 0.0f;

    cv::Mat faceRoi = gray(bestRect);
    const int upperH = static_cast<int>(faceRoi.rows * 0.50f);
    cv::Rect upper(0, 0, faceRoi.cols, upperH);
    cv::Mat upperRoi = faceRoi(upper);
    impl_->eye.detectMultiScale(upperRoi, eyes, 1.1, 5, 0, cv::Size(20, 20));
    if (!eyes.empty())
    {
      impl_->missingEyesFrames = 0;
      std::sort(eyes.begin(), eyes.end(), [](const cv::Rect &a, const cv::Rect &b)
                { return a.x < b.x; });
      cv::Rect leftEye = eyes.front();
      cv::Rect rightEye = eyes.size() > 1 ? eyes.back() : eyes.front();
      leftEye.y += upper.y;
      rightEye.y += upper.y;
      impl_->lastLeftEye = leftEye;
      impl_->lastRightEye = rightEye;

      const float leftRatio = static_cast<float>(leftEye.height) / std::max(1, leftEye.width);
      const float rightRatio = static_cast<float>(rightEye.height) / std::max(1, rightEye.width);
      current.eyeOpenL = clampFloat((leftRatio - 0.12f) / 0.20f, 0.0f, 1.0f);
      current.eyeOpenR = clampFloat((rightRatio - 0.12f) / 0.20f, 0.0f, 1.0f);

      const float lx = leftEye.x + leftEye.width * 0.5f;
      const float ly = leftEye.y + leftEye.height * 0.5f;
      const float rx = rightEye.x + rightEye.width * 0.5f;
      const float ry = rightEye.y + rightEye.height * 0.5f;
      const float dx = rx - lx;
      const float dy = ry - ly;
      if (std::abs(dx) > 1e-3f)
      {
        const float kPi = 3.14159265358979323846f;
        current.angleZ = clampFloat(std::atan2(dy, dx) * 180.0f / kPi, -30.0f, 30.0f);
      }

      const float eyeMidX = (lx + rx) * 0.5f;
      const float faceCx = bestRect.width * 0.5f;
      const float faceOffset = (eyeMidX - faceCx) / std::max(1.0f, bestRect.width * 0.5f);
      current.angleY = clampFloat(faceOffset * 35.0f, -35.0f, 35.0f);
    }
    else
    {
      impl_->missingEyesFrames++;
      if (impl_->missingEyesFrames < 5)
      {
        current.eyeOpenL = impl_->smoothed.eyeOpenL;
        current.eyeOpenR = impl_->smoothed.eyeOpenR;
      }
      else
      {
        current.eyeOpenL = 0.0f;
        current.eyeOpenR = 0.0f;
      }
    }

    int lowerStart = static_cast<int>(faceRoi.rows * 0.60f);
    if (!eyes.empty())
    {
      const float eyeMidY = (impl_->lastLeftEye.y + impl_->lastLeftEye.height * 0.5f +
                             impl_->lastRightEye.y + impl_->lastRightEye.height * 0.5f) * 0.5f;
      const int minStart = static_cast<int>(eyeMidY + faceRoi.rows * 0.15f);
      if (minStart > lowerStart)
        lowerStart = minStart;
    }
    const int minLower = static_cast<int>(faceRoi.rows * 0.55f);
    if (lowerStart < minLower)
      lowerStart = minLower;
    if (lowerStart >= faceRoi.rows)
      lowerStart = faceRoi.rows - 1;
    cv::Rect lower(0, lowerStart, faceRoi.cols,
             faceRoi.rows - lowerStart);
    cv::Mat lowerRoi = faceRoi(lower);
    const int minMouthW = std::max(40, static_cast<int>(bestRect.width * 0.30f));
    const int minMouthH = std::max(20, static_cast<int>(bestRect.height * 0.08f));
    impl_->mouth.detectMultiScale(lowerRoi, mouths, 1.10, 25, 0, cv::Size(minMouthW, minMouthH));
    if (!mouths.empty())
    {
      impl_->missingMouthFrames = 0;
      cv::Rect bestMouth;
      int bestArea = 0;
      for (const auto &m : mouths)
      {
        if (m.y + m.height * 0.5f < lowerRoi.rows * 0.35f)
          continue;
        const float aspect = static_cast<float>(m.width) / std::max(1, m.height);
        if (aspect < 1.0f || aspect > 4.0f)
          continue;
        const float cxm = m.x + m.width * 0.5f;
        if (cxm < lowerRoi.cols * 0.2f || cxm > lowerRoi.cols * 0.8f)
          continue;
        const int area = m.area();
        if (area > bestArea)
        {
          bestArea = area;
          bestMouth = m;
        }
      }
      if (bestArea > 0)
      {
        bestMouth.y += lower.y;
        impl_->lastMouth = bestMouth;
        const float mouthRatio = static_cast<float>(bestMouth.height) / std::max(1, bestRect.height);
        current.mouthOpen = clampFloat((mouthRatio - 0.02f) / 0.08f, 0.0f, 1.0f);
      }
      else
      {
        current.mouthOpen = impl_->smoothed.mouthOpen;
      }
    }
    else
    {
      impl_->missingMouthFrames++;
      current.mouthOpen = impl_->missingMouthFrames < 5 ? impl_->smoothed.mouthOpen : 0.0f;
    }
  }

  const float sharpnessAngle = 4.0f;
  const float sharpnessEye = 6.0f;
  const float sharpnessMouth = 6.0f;
  const auto applyDeadband = [](float prev, float next, float eps) {
    return std::abs(next - prev) < eps ? prev : next;
  };
  current.angleX = applyDeadband(impl_->smoothed.angleX, current.angleX, 0.4f);
  current.angleY = applyDeadband(impl_->smoothed.angleY, current.angleY, 0.4f);
  current.angleZ = applyDeadband(impl_->smoothed.angleZ, current.angleZ, 0.4f);
  current.eyeOpenL = applyDeadband(impl_->smoothed.eyeOpenL, current.eyeOpenL, 0.02f);
  current.eyeOpenR = applyDeadband(impl_->smoothed.eyeOpenR, current.eyeOpenR, 0.02f);
  current.mouthOpen = applyDeadband(impl_->smoothed.mouthOpen, current.mouthOpen, 0.02f);

  impl_->smoothed.hasFace = current.hasFace;
  impl_->smoothed.angleX = Smooth(impl_->smoothed.angleX, current.angleX, dtSeconds, sharpnessAngle);
  impl_->smoothed.angleY = Smooth(impl_->smoothed.angleY, current.angleY, dtSeconds, sharpnessAngle);
  impl_->smoothed.angleZ = Smooth(impl_->smoothed.angleZ, current.angleZ, dtSeconds, sharpnessAngle);
  impl_->smoothed.eyeOpenL = Smooth(impl_->smoothed.eyeOpenL, current.eyeOpenL, dtSeconds, sharpnessEye);
  impl_->smoothed.eyeOpenR = Smooth(impl_->smoothed.eyeOpenR, current.eyeOpenR, dtSeconds, sharpnessEye);
  impl_->smoothed.mouthOpen = Smooth(impl_->smoothed.mouthOpen, current.mouthOpen, dtSeconds, sharpnessMouth);

  outState = impl_->smoothed;

  if (impl_->debug)
  {
    if (current.hasFace)
    {
      cv::rectangle(frame, bestRect, cv::Scalar(0, 255, 0), 2);
      cv::putText(frame, "Face", cv::Point(bestRect.x + 4, bestRect.y - 6),
                  cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 255, 0), 1, cv::LINE_AA);
      for (const auto &e : eyes)
      {
        cv::Rect r = e;
        r.x += bestRect.x;
        r.y += bestRect.y;
        cv::rectangle(frame, r, cv::Scalar(255, 0, 0), 2);
        cv::putText(frame, "Eye", cv::Point(r.x + 2, r.y - 4),
                    cv::FONT_HERSHEY_SIMPLEX, 0.4, cv::Scalar(255, 0, 0), 1, cv::LINE_AA);
      }
      for (const auto &m : mouths)
      {
        cv::Rect r = m;
        r.x += bestRect.x;
        r.y += bestRect.y;
        cv::rectangle(frame, r, cv::Scalar(0, 0, 255), 2);
        cv::putText(frame, "Mouth", cv::Point(r.x + 2, r.y - 4),
                    cv::FONT_HERSHEY_SIMPLEX, 0.4, cv::Scalar(0, 0, 255), 1, cv::LINE_AA);
      }
    }
    char line1[128];
    char line2[128];
    char line3[128];
    std::snprintf(line1, sizeof(line1), "EyeL: %.2f  EyeR: %.2f", impl_->smoothed.eyeOpenL, impl_->smoothed.eyeOpenR);
    std::snprintf(line2, sizeof(line2), "Mouth: %.2f", impl_->smoothed.mouthOpen);
    std::snprintf(line3, sizeof(line3), "AngleX: %.1f  AngleY: %.1f  AngleZ: %.1f", impl_->smoothed.angleX, impl_->smoothed.angleY, impl_->smoothed.angleZ);

    cv::rectangle(frame, cv::Rect(5, 5, 360, 70), cv::Scalar(0, 0, 0), cv::FILLED);
    cv::putText(frame, line1, cv::Point(10, 25), cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 255, 255), 1, cv::LINE_AA);
    cv::putText(frame, line2, cv::Point(10, 45), cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 255, 255), 1, cv::LINE_AA);
    cv::putText(frame, line3, cv::Point(10, 65), cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 255, 255), 1, cv::LINE_AA);

    cv::imshow("Face Debug", frame);
    cv::waitKey(1);
  }

  return true;
}
