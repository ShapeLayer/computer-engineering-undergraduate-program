#ifndef __RFR_FACE_TRACKER_C_H__
#define __RFR_FACE_TRACKER_C_H__
#pragma once

#include "face_state.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct FaceTrackerC FaceTrackerC;

FaceTrackerC *face_tracker_create(const char *cascade_dir, int camera_index);
FaceTrackerC *face_tracker_create_ex(const char *cascade_dir, int camera_index,
									 const char *dnn_prototxt, const char *dnn_model);
void face_tracker_destroy(FaceTrackerC *tracker);
int face_tracker_update(FaceTrackerC *tracker, double dt_seconds, FaceStateC *out_state);
void face_tracker_set_debug(FaceTrackerC *tracker, int enable);

#ifdef __cplusplus
}
#endif
#endif  //__RFR_FACE_TRACKER_C_H__
