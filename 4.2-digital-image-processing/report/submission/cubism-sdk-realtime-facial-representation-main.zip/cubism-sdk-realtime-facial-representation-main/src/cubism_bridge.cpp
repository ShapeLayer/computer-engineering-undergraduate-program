#include "cubism_bridge.h"

#include <string>
#include <vector>
#include <memory>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <algorithm>
#include <unordered_set>
#include <unordered_map>
#include <fstream>
#include <cmath>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include <GL/glew.h>

#include "../external/json.h"

#include <CubismFramework.hpp>
#include <Model/CubismUserModel.hpp>
#include <Rendering/OpenGL/CubismRenderer_OpenGLES2.hpp>
#include <Math/CubismMatrix44.hpp>
#include <Math/CubismModelMatrix.hpp>
#include <Id/CubismIdManager.hpp>
#include <Live2DCubismCore.h>

using namespace Live2D::Cubism::Framework;

namespace
{
static float clamp_float(float v, float lo, float hi)
{
  return v < lo ? lo : (v > hi ? hi : v);
}

bool read_text_file(const std::filesystem::path &path, std::string &out)
{
  std::ifstream ifs(path, std::ios::binary | std::ios::ate);
  if (!ifs)
    return false;
  const std::streamsize size = ifs.tellg();
  if (size <= 0)
    return false;
  out.resize(static_cast<size_t>(size));
  ifs.seekg(0, std::ios::beg);
  if (!ifs.read(out.data(), size))
    return false;
  return true;
}

const json_value_s *json_object_get_value(const json_object_s *obj, const char *name)
{
  if (!obj || !name)
    return nullptr;
  for (const json_object_element_s *el = obj->start; el; el = el->next)
  {
    if (!el->name)
      continue;
    const char *n = el->name->string;
    const size_t nlen = el->name->string_size;
    if (n && nlen == strlen(name) && std::memcmp(n, name, nlen) == 0)
    {
      return el->value;
    }
  }
  return nullptr;
}

void json_collect_string_array(const json_value_s *value, std::vector<std::string> &out)
{
  if (!value)
    return;
  json_array_s *arr = json_value_as_array(const_cast<json_value_s *>(value));
  if (!arr)
    return;
  for (json_array_element_s *el = arr->start; el; el = el->next)
  {
    json_string_s *s = json_value_as_string(el->value);
    if (s && s->string && s->string_size > 0)
    {
      out.emplace_back(s->string, s->string_size);
    }
  }
}

bool load_render_settings_file(const std::filesystem::path &path,
                               std::vector<std::string> &order,
                               std::vector<std::string> &hidden)
{
  std::string data;
  if (!read_text_file(path, data))
    return false;
  json_value_s *root = json_parse(data.data(), data.size());
  if (!root)
    return false;
  json_object_s *obj = json_value_as_object(root);
  if (obj)
  {
    const json_value_s *orderVal = json_object_get_value(obj, "order");
    const json_value_s *hiddenVal = json_object_get_value(obj, "hidden");
    json_collect_string_array(orderVal, order);
    json_collect_string_array(hiddenVal, hidden);
  }
  std::free(root);
  return !order.empty() || !hidden.empty();
}

void log_parts_info(const std::filesystem::path &path)
{
  std::string data;
  if (!read_text_file(path, data))
    return;
  json_value_s *root = json_parse(data.data(), data.size());
  if (!root)
    return;
  json_object_s *obj = json_value_as_object(root);
  if (obj)
  {
    const json_value_s *facePartsVal = json_object_get_value(obj, "face_parts");
    json_object_s *facePartsObj = json_value_as_object(const_cast<json_value_s *>(facePartsVal));
    if (facePartsObj)
    {
      size_t groupCount = 0;
      size_t idCount = 0;
      for (json_object_element_s *el = facePartsObj->start; el; el = el->next)
      {
        ++groupCount;
        if (el->value)
        {
          json_array_s *arr = json_value_as_array(el->value);
          if (arr)
          {
            for (json_array_element_s *ae = arr->start; ae; ae = ae->next)
            {
              json_string_s *s = json_value_as_string(ae->value);
              if (s && s->string_size > 0)
                ++idCount;
            }
          }
        }
      }
      std::fprintf(stderr, "[Cubism] Parts info: %zu groups, %zu ids (%s)\n", groupCount, idCount, path.string().c_str());
    }
  }
  std::free(root);
}

bool load_face_parts_ids(const std::filesystem::path &path,
                         const std::vector<std::string> &groups,
                         std::unordered_set<std::string> &outIds)
{
  std::string data;
  if (!read_text_file(path, data))
    return false;
  json_value_s *root = json_parse(data.data(), data.size());
  if (!root)
    return false;
  json_object_s *obj = json_value_as_object(root);
  if (obj)
  {
    const json_value_s *facePartsVal = json_object_get_value(obj, "face_parts");
    json_object_s *facePartsObj = json_value_as_object(const_cast<json_value_s *>(facePartsVal));
    if (facePartsObj)
    {
      for (const auto &group : groups)
      {
        const json_value_s *groupVal = json_object_get_value(facePartsObj, group.c_str());
        std::vector<std::string> ids;
        json_collect_string_array(groupVal, ids);
        for (const auto &id : ids)
          outIds.insert(id);
      }
    }
  }
  std::free(root);
  return !outIds.empty();
}

void log_moc3_json_info(const std::filesystem::path &path)
{
  std::string data;
  if (!read_text_file(path, data))
    return;
  json_value_s *root = json_parse(data.data(), data.size());
  if (!root)
    return;
  json_object_s *obj = json_value_as_object(root);
  if (obj)
  {
    const json_value_s *drawablesVal = json_object_get_value(obj, "drawables");
    json_array_s *arr = json_value_as_array(const_cast<json_value_s *>(drawablesVal));
    if (arr)
    {
      std::fprintf(stderr, "[Cubism] Moc3 json: drawables=%zu (%s)\n", arr->length, path.string().c_str());
    }
  }
  std::free(root);
}

static bool ends_with(const std::string &value, const std::string &suffix)
{
  if (value.size() < suffix.size())
    return false;
  return std::equal(suffix.rbegin(), suffix.rend(), value.rbegin());
}

static bool resolve_moc3_path(const std::filesystem::path &input,
                              std::filesystem::path &outMoc3,
                              std::filesystem::path &outMoc3Json)
{
  outMoc3.clear();
  outMoc3Json.clear();

  const std::string inputStr = input.string();
  const std::string suffix = ".moc3.json";
  if (!ends_with(inputStr, suffix))
  {
    outMoc3 = input;
    return true;
  }

  outMoc3Json = input;
  std::string filename = input.filename().string();
  if (filename.size() <= suffix.size())
    return false;
  const std::string base = filename.substr(0, filename.size() - suffix.size());
  const std::string mocName = base + ".moc3";

  std::vector<std::filesystem::path> candidates;
  const std::filesystem::path parent = input.parent_path();
  if (!parent.empty())
  {
    candidates.push_back(parent / mocName);
    if (parent.has_parent_path())
      candidates.push_back(parent.parent_path() / mocName);
    if (parent.has_parent_path() && parent.parent_path().has_parent_path())
      candidates.push_back(parent.parent_path().parent_path() / mocName);
  }

  for (const auto &p : candidates)
  {
    if (std::filesystem::exists(p))
    {
      outMoc3 = p;
      return true;
    }
  }

  std::filesystem::path searchRoot = parent.empty() ? input.parent_path() : parent;
  if (searchRoot.empty())
  {
    std::error_code cwdEc;
    searchRoot = std::filesystem::current_path(cwdEc);
  }
  for (int i = 0; i < 4 && searchRoot.has_parent_path(); ++i)
  {
    if (searchRoot.filename() == "live2d-models")
      break;
    searchRoot = searchRoot.parent_path();
  }

  std::error_code ec;
  for (std::filesystem::recursive_directory_iterator it(searchRoot, std::filesystem::directory_options::skip_permission_denied, ec), end;
       it != end; it.increment(ec))
  {
    if (ec)
      continue;
    if (!it->is_regular_file())
      continue;
    if (it->path().filename() == mocName)
    {
      outMoc3 = it->path();
      return true;
    }
  }

  return false;
}

class Model : public CubismUserModel
{
public:
  Model() = default;
  ~Model() override = default;

  bool LoadFromMoc3(const std::string &moc3Path)
  {
    csmSizeInt size = 0;
    csmByte *mocBuffer = CreateBuffer(moc3Path.c_str(), &size);
    if (!mocBuffer)
    {
      return false;
    }

    if (size < 4 || std::memcmp(mocBuffer, "MOC3", 4) != 0)
    {
      std::fprintf(stderr, "[Cubism] Invalid moc3 header for %s (size=%d)\n",
                   moc3Path.c_str(), static_cast<int>(size));
      DeleteBuffer(mocBuffer, moc3Path.c_str());
      return false;
    }

    LoadModel(mocBuffer, size);
    DeleteBuffer(mocBuffer, moc3Path.c_str());

    if (!GetModel())
    {
      return false;
    }

    if (auto *m = GetModel())
    {
      canvasWidth = m->GetCanvasWidth();
      canvasHeight = m->GetCanvasHeight();
      pixelsPerUnit = m->GetPixelsPerUnit();
      std::fprintf(stderr, "[Cubism] Canvas: %.2f x %.2f (ppu=%.2f)\n",
                   canvasWidth, canvasHeight, pixelsPerUnit);
    }

    CreateRenderer();
    if (auto *mat = GetModelMatrix())
    {
      mat->SetHeight(canvasHeight > 0.0f ? canvasHeight : 1.0f);
      mat->SetCenterPosition(0.0f, 0.0f);
    }
    ComputeBaseCenter();
    LoadTexturesFromDir(moc3Path);
    return true;
  }

  void DrawWithProjection(CubismMatrix44 &projection)
  {
    if (!GetModel())
    {
      return;
    }
    projection.TranslateRelative(-baseCenterX, -baseCenterY);
    projection.MultiplyByMatrix(GetModelMatrix());
    GetRenderer<Rendering::CubismRenderer_OpenGLES2>()->SetMvpMatrix(&projection);
    GetRenderer<Rendering::CubismRenderer_OpenGLES2>()->DrawModel();
  }

  float GetPixelsPerUnit() const { return pixelsPerUnit <= 0.0f ? 1.0f : pixelsPerUnit; }
  float GetCanvasHeight() const { return canvasHeight > 0.0f ? canvasHeight : 1.0f; }

protected:
  csmByte *CreateBuffer(const csmChar *path, csmSizeInt *size)
  {
    FILE *fp = fopen(path, "rb");
    if (!fp)
    {
      return nullptr;
    }
    fseek(fp, 0, SEEK_END);
    long fsize = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    if (fsize <= 0)
    {
      fclose(fp);
      return nullptr;
    }
    csmByte *buffer = new csmByte[fsize];
    if (fread(buffer, 1, static_cast<size_t>(fsize), fp) != static_cast<size_t>(fsize))
    {
      delete[] buffer;
      fclose(fp);
      return nullptr;
    }
    fclose(fp);
    *size = static_cast<csmSizeInt>(fsize);
    return buffer;
  }

  void DeleteBuffer(csmByte *buffer, const csmChar *)
  {
    delete[] buffer;
  }

  void ComputeBaseCenter()
  {
    baseCenterX = 0.0f;
    baseCenterY = 0.0f;
    CubismModel *m = GetModel();
    if (!m)
      return;

    const csmInt32 drawableCount = m->GetDrawableCount();
    float minX = 1e9f;
    float minY = 1e9f;
    float maxX = -1e9f;
    float maxY = -1e9f;
    for (csmInt32 i = 0; i < drawableCount; ++i)
    {
      const csmFloat32 *verts = m->GetDrawableVertices(i);
      const csmInt32 vcount = m->GetDrawableVertexCount(i);
      if (!verts || vcount <= 0)
        continue;
      for (csmInt32 v = 0; v < vcount; ++v)
      {
        const float x = verts[v * 2 + 0];
        const float y = verts[v * 2 + 1];
        minX = std::min(minX, x);
        minY = std::min(minY, y);
        maxX = std::max(maxX, x);
        maxY = std::max(maxY, y);
      }
    }
    if (minX < maxX && minY < maxY)
    {
      baseCenterX = (minX + maxX) * 0.5f;
      baseCenterY = (minY + maxY) * 0.5f;
      std::fprintf(stderr, "[Cubism] Base center: %.3f, %.3f\n", baseCenterX, baseCenterY);
    }
  }

  void LoadTexturesFromDir(const std::string &moc3Path)
  {
    std::filesystem::path baseDir = std::filesystem::path(moc3Path).parent_path();
    if (baseDir.empty())
      return;

    auto *renderer = GetRenderer<Rendering::CubismRenderer_OpenGLES2>();
    if (!renderer)
      return;

    CubismModel *model = GetModel();
    std::unordered_set<int> usedTextureIndices;
    if (model)
    {
      const csmInt32 drawableCount = model->GetDrawableCount();
      for (csmInt32 i = 0; i < drawableCount; ++i)
      {
        int texIdx = model->GetDrawableTextureIndex(i);
        if (texIdx >= 0)
          usedTextureIndices.insert(texIdx);
      }
      std::fprintf(stderr, "[Cubism] Drawables: %d, Unique texture indices: %zu\n", drawableCount, usedTextureIndices.size());
    }

    auto bindTextureFile = [&](const std::filesystem::path &texPath, int index)
    {
      cv::Mat img = cv::imread(texPath.string(), cv::IMREAD_UNCHANGED);
      if (img.empty())
        return false;

      cv::Mat rgba;
      if (img.channels() == 4)
      {
        cv::cvtColor(img, rgba, cv::COLOR_BGRA2RGBA);
      }
      else if (img.channels() == 3)
      {
        cv::cvtColor(img, rgba, cv::COLOR_BGR2RGBA);
      }
      else
      {
        cv::cvtColor(img, rgba, cv::COLOR_GRAY2RGBA);
      }

      cv::Mat flipped = rgba;

      GLuint tex = 0;
      glGenTextures(1, &tex);
      glBindTexture(GL_TEXTURE_2D, tex);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
      glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, flipped.cols, flipped.rows, 0, GL_RGBA, GL_UNSIGNED_BYTE, flipped.data);

      renderer->BindTexture(static_cast<csmUint32>(index), tex);
      std::fprintf(stderr, "[Cubism] Bind texture[%d] <- %s\n", index, texPath.string().c_str());
      return true;
    };

    int boundCount = 0;
    for (int i = 0; i < 32; ++i)
    {
      char name[32];
      std::snprintf(name, sizeof(name), "texture_%02d.png", i);
      std::filesystem::path texPath = baseDir / name;
      if (!std::filesystem::exists(texPath))
        continue;
      if (bindTextureFile(texPath, i))
        ++boundCount;
    }

    int foundAny = 0;
    if (boundCount == 0)
    {
      std::vector<std::filesystem::path> pngs;
      std::vector<std::filesystem::path> texNamed;
      for (auto &entry : std::filesystem::recursive_directory_iterator(baseDir))
      {
        if (!entry.is_regular_file())
          continue;
        auto ext = entry.path().extension().string();
        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
        if (ext != ".png")
          continue;
        foundAny = 1;
        const std::string filename = entry.path().filename().string();
        if (filename.rfind("texture_", 0) == 0)
          texNamed.push_back(entry.path());
        else
          pngs.push_back(entry.path());
      }

      auto parseIndex = [](const std::string &name, int *out) -> bool
      {
        if (name.rfind("texture_", 0) != 0)
          return false;
        size_t dot = name.find_last_of('.');
        if (dot == std::string::npos || dot <= 8)
          return false;
        std::string num = name.substr(8, dot - 8);
        try
        {
          *out = std::stoi(num);
          return true;
        }
        catch (...)
        {
          return false;
        }
      };

      std::sort(texNamed.begin(), texNamed.end());
      for (const auto &p : texNamed)
      {
        int idx = -1;
        if (parseIndex(p.filename().string(), &idx) && idx >= 0)
        {
          if (bindTextureFile(p, idx))
            ++boundCount;
        }
      }

      if (boundCount == 0)
      {
        std::sort(pngs.begin(), pngs.end());
        int idx = 0;
        for (const auto &p : pngs)
        {
          if (bindTextureFile(p, idx))
            ++boundCount;
          ++idx;
        }
      }
    }

    if (boundCount == 0)
    {
      std::fprintf(stderr, "[Cubism] No textures found near %s\n", baseDir.string().c_str());
    }
    else
    {
      std::fprintf(stderr, "[Cubism] Bound %d texture(s) from %s\n", boundCount, baseDir.string().c_str());
    }

    if (!foundAny)
    {
      std::fprintf(stderr, "[Cubism] No .png files discovered under %s\n", baseDir.string().c_str());
    }

    if (boundCount == 0 && model && !usedTextureIndices.empty())
    {
      GLuint tex = 0;
      unsigned char white[4] = {255, 255, 255, 255};
      glGenTextures(1, &tex);
      glBindTexture(GL_TEXTURE_2D, tex);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
      glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, white);
      for (int idx : usedTextureIndices)
      {
        renderer->BindTexture(static_cast<csmUint32>(idx), tex);
      }
      std::fprintf(stderr, "[Cubism] Bound fallback white texture to %zu indices\n", usedTextureIndices.size());
    }

    if (renderer)
    {
      renderer->IsPremultipliedAlpha(false);
    }
  }

private:
  float baseCenterX = 0.0f;
  float baseCenterY = 0.0f;
  float pixelsPerUnit = 1.0f;
  float canvasWidth = 1.0f;
  float canvasHeight = 1.0f;
};

class SimpleAllocator : public ICubismAllocator
{
public:
  void *Allocate(const csmSizeType size) override { return malloc(size); }
  void Deallocate(void *memory) override { free(memory); }
  void *AllocateAligned(const csmSizeType size, const csmUint32 alignment) override
  {
    void *ptr = nullptr;
#if defined(_MSC_VER)
    ptr = _aligned_malloc(size, alignment);
#elif defined(__APPLE__) || defined(__linux__)
    if (posix_memalign(&ptr, alignment, size) != 0)
      ptr = nullptr;
#else
    ptr = malloc(size);
#endif
    return ptr;
  }
  void DeallocateAligned(void *alignedMemory) override
  {
#if defined(_MSC_VER)
    _aligned_free(alignedMemory);
#else
    free(alignedMemory);
#endif
  }
};

} // namespace

struct CubismBridge
{
  SimpleAllocator allocator;
  Model model;
  int width = 0;
  int height = 0;
  CubismIdHandle idParamAngleX = nullptr;
  CubismIdHandle idParamAngleY = nullptr;
  CubismIdHandle idParamAngleZ = nullptr;
  CubismIdHandle idParamEyeLOpen = nullptr;
  CubismIdHandle idParamEyeROpen = nullptr;
  CubismIdHandle idParamMouthOpenY = nullptr;
  CubismIdHandle idParamMouthOpen = nullptr;
  int debugPrinted = 0;
  float viewPanX = 0.0f;
  float viewPanY = 0.0f;
  float viewScale = 1.0f;
  std::vector<int> renderOrderOverride;
  std::vector<int> hiddenDrawableIndices;
  std::vector<int> mouthInnerDrawableIndices;
  float lastMouthOpen = 0.0f;
  bool useMouthParts = false;
};

static void cubism_log(const char *message)
{
  std::fprintf(stderr, "[CubismSDK] %s\n", message);
}

static csmByte *cubism_load_file(const std::string filePath, csmSizeInt *outSize)
{
  if (outSize)
    *outSize = 0;

  std::vector<std::filesystem::path> candidates;
  candidates.emplace_back(filePath);

  std::filesystem::path p(filePath);
  if (!p.is_absolute())
  {
    const auto cwd = std::filesystem::current_path();
    candidates.emplace_back(cwd / p);
    if (p.filename() != p)
    {
      candidates.emplace_back(cwd / p.filename());
    }
    candidates.emplace_back(cwd / "FrameworkShaders" / p.filename());
    candidates.emplace_back(cwd / "../FrameworkShaders" / p.filename());
    candidates.emplace_back(cwd / "build" / "FrameworkShaders" / p.filename());
    candidates.emplace_back(cwd / "../build" / "FrameworkShaders" / p.filename());
  }

  for (const auto &cand : candidates)
  {
    std::ifstream ifs(cand, std::ios::binary | std::ios::ate);
    if (!ifs)
      continue;
    const std::streamsize size = ifs.tellg();
    if (size <= 0)
      continue;
    ifs.seekg(0, std::ios::beg);
    csmByte *buffer = reinterpret_cast<csmByte *>(std::malloc(static_cast<size_t>(size)));
    if (!buffer)
      return nullptr;
    if (!ifs.read(reinterpret_cast<char *>(buffer), size))
    {
      std::free(buffer);
      continue;
    }
    if (outSize)
      *outSize = static_cast<csmSizeInt>(size);
    return buffer;
  }

  return nullptr;
}

static void cubism_release_bytes(csmByte *data)
{
  std::free(data);
}

CubismBridge *cubism_bridge_create(const char *moc3_path)
{
  if (!moc3_path)
  {
    return nullptr;
  }

  std::filesystem::path resolvedMoc3Path;
  std::filesystem::path moc3JsonInput;
  if (!resolve_moc3_path(std::filesystem::path(moc3_path), resolvedMoc3Path, moc3JsonInput))
  {
    std::fprintf(stderr, "[Cubism] Failed to resolve .moc3 from input: %s\n", moc3_path);
    return nullptr;
  }
  const std::string resolvedMoc3 = resolvedMoc3Path.string();
  if (!moc3JsonInput.empty())
  {
    std::fprintf(stderr, "[Cubism] Resolved moc3 from json: %s -> %s\n",
                 moc3_path, resolvedMoc3.c_str());
  }

  static bool s_inited = false;
  static CubismFramework::Option s_option;
  static SimpleAllocator s_allocator;

  if (!s_inited)
  {
    s_option.LogFunction = cubism_log;
    s_option.LoggingLevel = CubismFramework::Option::LogLevel_Verbose;
    s_option.LoadFileFunction = cubism_load_file;
    s_option.ReleaseBytesFunction = cubism_release_bytes;
    CubismFramework::StartUp(&s_allocator, &s_option);
    CubismFramework::Initialize();
    s_inited = true;
  }

  CubismBridge *bridge = new CubismBridge();
  bridge->useMouthParts = !moc3JsonInput.empty();
  if (!bridge->model.LoadFromMoc3(resolvedMoc3))
  {
    delete bridge;
    return nullptr;
  }

  if (!moc3JsonInput.empty() && std::filesystem::exists(moc3JsonInput))
  {
    log_moc3_json_info(moc3JsonInput);
  }

  if (auto *m = bridge->model.GetModel())
  {
    const csmInt32 drawableCount = m->GetDrawableCount();
    std::unordered_map<std::string, int> drawableMap;
    drawableMap.reserve(static_cast<size_t>(drawableCount));
    for (csmInt32 i = 0; i < drawableCount; ++i)
    {
      const CubismIdHandle id = m->GetDrawableId(i);
      if (id)
      {
        drawableMap.emplace(id->GetString().GetRawString(), i);
      }
    }

    std::filesystem::path moc3Path(resolvedMoc3);
    std::filesystem::path base = moc3Path;
    if (base.extension() == ".moc3")
    {
      base.replace_extension("");
    }

    std::filesystem::path renderSettingsPath = base;
    renderSettingsPath += ".moc3.render-settings.json";
    std::filesystem::path partsPath = base;
    partsPath += ".moc3.parts.json";
    std::filesystem::path moc3JsonPath = base;
    moc3JsonPath += ".moc3.json";

    if (std::filesystem::exists(moc3JsonPath))
    {
      log_moc3_json_info(moc3JsonPath);
    }

    if (std::filesystem::exists(partsPath))
    {
      log_parts_info(partsPath);

      if (bridge->useMouthParts)
      {
        std::unordered_set<std::string> mouthIds;
        const std::vector<std::string> innerGroups = {"mouth_inner", "mouth_in", "tongue", "teeth"};
        bool foundInner = load_face_parts_ids(partsPath, innerGroups, mouthIds);
        if (!foundInner)
        {
          const std::vector<std::string> fallbackGroups = {"tongue", "teeth"};
          foundInner = load_face_parts_ids(partsPath, fallbackGroups, mouthIds);
        }
        if (foundInner)
        {
          for (const auto &id : mouthIds)
          {
            auto it = drawableMap.find(id);
            if (it != drawableMap.end())
              bridge->mouthInnerDrawableIndices.push_back(it->second);
          }
        }
      }
    }

    std::vector<std::string> orderIds;
    std::vector<std::string> hiddenIds;
    if (std::filesystem::exists(renderSettingsPath) &&
        load_render_settings_file(renderSettingsPath, orderIds, hiddenIds))
    {
      std::fprintf(stderr, "[Cubism] Render settings: order=%zu hidden=%zu (%s)\n",
                   orderIds.size(), hiddenIds.size(), renderSettingsPath.string().c_str());

      if (!moc3JsonInput.empty() && orderIds.size() > 1)
      {
        const csmInt32 *baseOrders = m->GetDrawableRenderOrders();
        int inc = 0;
        int dec = 0;
        int prev = 0;
        bool hasPrev = false;
        for (const auto &id : orderIds)
        {
          auto it = drawableMap.find(id);
          if (it == drawableMap.end())
            continue;
          const int cur = baseOrders[it->second];
          if (hasPrev)
          {
            if (cur > prev)
              ++inc;
            else if (cur < prev)
              ++dec;
          }
          prev = cur;
          hasPrev = true;
        }

        if (dec > inc)
        {
          std::reverse(orderIds.begin(), orderIds.end());
          std::fprintf(stderr, "[Cubism] Render order reversed for moc3.json (%s)\n",
                       renderSettingsPath.string().c_str());
        }
      }

      if (!orderIds.empty())
      {
        bridge->renderOrderOverride.assign(static_cast<size_t>(drawableCount), -1);
        csmInt32 orderPos = 0;
        for (const auto &id : orderIds)
        {
          if (orderPos >= drawableCount)
            break;
          auto it = drawableMap.find(id);
          if (it == drawableMap.end())
            continue;
          bridge->renderOrderOverride[static_cast<size_t>(it->second)] = orderPos++;
        }

        const csmInt32 *baseOrders = m->GetDrawableRenderOrders();
        std::vector<int> remaining;
        remaining.reserve(static_cast<size_t>(drawableCount));
        for (csmInt32 i = 0; i < drawableCount; ++i)
        {
          if (bridge->renderOrderOverride[static_cast<size_t>(i)] < 0)
            remaining.push_back(i);
        }
        std::sort(remaining.begin(), remaining.end(), [&](int a, int b) {
          return baseOrders[a] < baseOrders[b];
        });

        for (int idx : remaining)
        {
          if (orderPos >= drawableCount)
            break;
          bridge->renderOrderOverride[static_cast<size_t>(idx)] = orderPos++;
        }
      }

      if (!hiddenIds.empty())
      {
        std::unordered_set<int> uniqueHidden;
        for (const auto &id : hiddenIds)
        {
          auto it = drawableMap.find(id);
          if (it != drawableMap.end())
          {
            uniqueHidden.insert(it->second);
          }
        }
        bridge->hiddenDrawableIndices.assign(uniqueHidden.begin(), uniqueHidden.end());
      }
    }
  }

  bridge->idParamAngleX = CubismFramework::GetIdManager()->GetId("ParamAngleX");
  bridge->idParamAngleY = CubismFramework::GetIdManager()->GetId("ParamAngleY");
  bridge->idParamAngleZ = CubismFramework::GetIdManager()->GetId("ParamAngleZ");
  bridge->idParamEyeLOpen = CubismFramework::GetIdManager()->GetId("ParamEyeLOpen");
  bridge->idParamEyeROpen = CubismFramework::GetIdManager()->GetId("ParamEyeROpen");
  bridge->idParamMouthOpenY = CubismFramework::GetIdManager()->GetId("ParamMouthOpenY");
  bridge->idParamMouthOpen = CubismFramework::GetIdManager()->GetId("ParamMouthOpen");
  bridge->viewPanY = 0.0f;
  return bridge;
}

void cubism_bridge_destroy(CubismBridge *bridge)
{
  delete bridge;
}

void cubism_bridge_resize(CubismBridge *bridge, int width, int height)
{
  if (!bridge)
  {
    return;
  }
  bridge->width = width;
  bridge->height = height;
}

void cubism_bridge_update(CubismBridge *bridge, float)
{
  if (!bridge)
  {
    return;
  }
  if (!bridge->model.GetModel())
  {
    return;
  }
  bridge->model.GetModel()->Update();

  if (!bridge->renderOrderOverride.empty())
  {
    csmInt32 *renderOrders = const_cast<csmInt32 *>(bridge->model.GetModel()->GetDrawableRenderOrders());
    if (renderOrders)
    {
      for (size_t i = 0; i < bridge->renderOrderOverride.size(); ++i)
      {
        const int v = bridge->renderOrderOverride[i];
        if (v >= 0)
          renderOrders[i] = v;
      }
    }
  }

  if (!bridge->hiddenDrawableIndices.empty())
  {
    Live2D::Cubism::Core::csmModel *coreModel = bridge->model.GetModel()->GetModel();
    const csmFloat32 *opacitiesConst = coreModel ? Live2D::Cubism::Core::csmGetDrawableOpacities(coreModel) : nullptr;
    csmFloat32 *opacities = const_cast<csmFloat32 *>(opacitiesConst);
    if (opacities)
    {
      const csmInt32 drawableCount = bridge->model.GetModel()->GetDrawableCount();
      for (int idx : bridge->hiddenDrawableIndices)
      {
        if (idx >= 0 && idx < drawableCount)
          opacities[idx] = 0.0f;
      }
    }
  }

  if (bridge->useMouthParts && !bridge->mouthInnerDrawableIndices.empty())
  {
    Live2D::Cubism::Core::csmModel *coreModel = bridge->model.GetModel()->GetModel();
    const csmFloat32 *opacitiesConst = coreModel ? Live2D::Cubism::Core::csmGetDrawableOpacities(coreModel) : nullptr;
    csmFloat32 *opacities = const_cast<csmFloat32 *>(opacitiesConst);
    if (opacities)
    {
      const float innerAlpha = clamp_float((bridge->lastMouthOpen - 0.05f) / 0.6f, 0.0f, 1.0f);
      const csmInt32 drawableCount = bridge->model.GetModel()->GetDrawableCount();
      for (int idx : bridge->mouthInnerDrawableIndices)
      {
        if (idx >= 0 && idx < drawableCount)
          opacities[idx] = innerAlpha;
      }
    }
  }

  if (!bridge->debugPrinted)
  {
    CubismModel *m = bridge->model.GetModel();
    const csmInt32 drawableCount = m->GetDrawableCount();
    int visibleCount = 0;
    int nonZeroOpacity = 0;
    for (csmInt32 i = 0; i < drawableCount; ++i)
    {
      if (m->GetDrawableDynamicFlagIsVisible(i))
        ++visibleCount;
      if (m->GetDrawableOpacity(i) > 0.001f)
        ++nonZeroOpacity;
    }
    std::fprintf(stderr, "[Cubism] Visible drawables: %d / %d, Opacity>0: %d\n", visibleCount, drawableCount, nonZeroOpacity);
    if (drawableCount > 0)
    {
      const csmFloat32 *verts = m->GetDrawableVertices(0);
      const csmInt32 vcount = m->GetDrawableVertexCount(0);
      if (verts && vcount >= 2)
      {
        std::fprintf(stderr, "[Cubism] Drawable0 v0=(%.3f, %.3f) vcount=%d\n", verts[0], verts[1], vcount);
      }
    }
    bridge->debugPrinted = 1;
  }
}

void cubism_bridge_draw(CubismBridge *bridge)
{
  if (!bridge)
  {
    return;
  }
  if (!bridge->model.GetModel())
  {
    return;
  }

  CubismMatrix44 projection;
  if (bridge->width > 0 && bridge->height > 0)
  {
    const float sx = 2.0f / static_cast<float>(bridge->width);
    const float sy = 2.0f / static_cast<float>(bridge->height);
    const float ppu = bridge->model.GetPixelsPerUnit();
    projection.ScaleRelative(sx * ppu, sy * ppu);
  }

  const float ppu = bridge->model.GetPixelsPerUnit();
  const float snapX = std::round(bridge->viewPanX * ppu) / ppu;
  const float snapY = std::round(bridge->viewPanY * ppu) / ppu;
  projection.ScaleRelative(bridge->viewScale, bridge->viewScale);
  projection.TranslateRelative(snapX, snapY);

  bridge->model.DrawWithProjection(projection);
}

void cubism_bridge_apply_face_state(CubismBridge *bridge, const FaceStateC *state)
{
  if (!bridge || !state)
  {
    return;
  }
  if (!bridge->model.GetModel())
  {
    return;
  }

  float angleX = state->has_face ? state->angle_x : 0.0f;
  float angleY = state->has_face ? state->angle_y : 0.0f;
  float angleZ = state->has_face ? state->angle_z : 0.0f;
  float eyeL = state->has_face ? state->eye_open_l : 1.0f;
  float eyeR = state->has_face ? state->eye_open_r : 1.0f;
  float mouth = state->has_face ? state->mouth_open : 0.0f;

  angleX = clamp_float(angleX, -30.0f, 30.0f);
  angleY = clamp_float(angleY, -30.0f, 30.0f);
  angleZ = clamp_float(angleZ, -30.0f, 30.0f);
  eyeL = clamp_float(eyeL, 0.0f, 1.0f);
  eyeR = clamp_float(eyeR, 0.0f, 1.0f);
  mouth = clamp_float(mouth, 0.0f, 1.0f);
  bridge->lastMouthOpen = mouth;

  if (bridge->idParamAngleX) bridge->model.GetModel()->SetParameterValue(bridge->idParamAngleX, angleX);
  if (bridge->idParamAngleY) bridge->model.GetModel()->SetParameterValue(bridge->idParamAngleY, angleY);
  if (bridge->idParamAngleZ) bridge->model.GetModel()->SetParameterValue(bridge->idParamAngleZ, angleZ);
  if (bridge->idParamEyeLOpen) bridge->model.GetModel()->SetParameterValue(bridge->idParamEyeLOpen, eyeL);
  if (bridge->idParamEyeROpen) bridge->model.GetModel()->SetParameterValue(bridge->idParamEyeROpen, eyeR);

  if (bridge->idParamMouthOpenY)
  {
    bridge->model.GetModel()->SetParameterValue(bridge->idParamMouthOpenY, mouth);
  }
  else if (bridge->idParamMouthOpen)
  {
    bridge->model.GetModel()->SetParameterValue(bridge->idParamMouthOpen, mouth);
  }
}

void cubism_bridge_set_view(CubismBridge *bridge, float pan_x, float pan_y, float scale)
{
  if (!bridge)
    return;
  bridge->viewPanX = pan_x;
  bridge->viewPanY = pan_y;
  bridge->viewScale = scale > 0.01f ? scale : 0.01f;
}
