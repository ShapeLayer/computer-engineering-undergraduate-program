#ifndef __RFR_FACE_STATE_H__
#define __RFR_FACE_STATE_H__
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

typedef struct FaceStateC
{
  int has_face;
  float angle_x;
  float angle_y;
  float angle_z;
  float eye_open_l;
  float eye_open_r;
  float mouth_open;
} FaceStateC;

#ifdef __cplusplus
}
#endif
#endif  //__RFR_FACE_STATE_H__
