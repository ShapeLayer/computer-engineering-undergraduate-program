#ifndef __RFR_FACE_TRACKER_H__
#define __RFR_FACE_TRACKER_H__
#pragma once

#include <string>

struct FaceState
{
  bool hasFace = false;
  float angleX = 0.0f;
  float angleY = 0.0f;
  float angleZ = 0.0f;
  float eyeOpenL = 1.0f;
  float eyeOpenR = 1.0f;
  float mouthOpen = 0.0f;
};

class FaceTracker
{
public:
  FaceTracker();
  ~FaceTracker();

  bool Initialize(const std::string &cascadeDir, int cameraIndex,
                  const std::string &dnnProtoPath = std::string(),
                  const std::string &dnnModelPath = std::string());
  void SetDebug(bool enable);
  bool Update(double dtSeconds, FaceState &outState);

private:
  float Smooth(float prev, float next, double dtSeconds, float sharpness) const;
  bool EnsureCascades(const std::string &cascadeDir);

  struct Impl;
  Impl *impl_ = nullptr;
};

#endif  //__RFR_FACE_TRACKER_H__
