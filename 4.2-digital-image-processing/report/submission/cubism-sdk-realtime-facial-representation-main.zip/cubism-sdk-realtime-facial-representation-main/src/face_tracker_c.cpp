#include "face_tracker_c.h"
#include "face_tracker.h"

struct FaceTrackerC
{
  FaceTracker tracker;
};

FaceTrackerC *face_tracker_create(const char *cascade_dir, int camera_index)
{
  return face_tracker_create_ex(cascade_dir, camera_index, nullptr, nullptr);
}

FaceTrackerC *face_tracker_create_ex(const char *cascade_dir, int camera_index,
                                     const char *dnn_prototxt, const char *dnn_model)
{
  if (!cascade_dir)
  {
    return nullptr;
  }
  FaceTrackerC *wrapper = new FaceTrackerC();
  const std::string proto = dnn_prototxt ? dnn_prototxt : std::string();
  const std::string model = dnn_model ? dnn_model : std::string();
  if (!wrapper->tracker.Initialize(cascade_dir, camera_index, proto, model))
  {
    delete wrapper;
    return nullptr;
  }
  return wrapper;
}

void face_tracker_destroy(FaceTrackerC *tracker)
{
  delete tracker;
}

int face_tracker_update(FaceTrackerC *tracker, double dt_seconds, FaceStateC *out_state)
{
  if (!tracker || !out_state)
  {
    return 0;
  }

  FaceState state;
  const bool ok = tracker->tracker.Update(dt_seconds, state);

  out_state->has_face = state.hasFace ? 1 : 0;
  out_state->angle_x = state.angleX;
  out_state->angle_y = state.angleY;
  out_state->angle_z = state.angleZ;
  out_state->eye_open_l = state.eyeOpenL;
  out_state->eye_open_r = state.eyeOpenR;
  out_state->mouth_open = state.mouthOpen;

  return ok ? 1 : 0;
}

void face_tracker_set_debug(FaceTrackerC *tracker, int enable)
{
  if (!tracker)
    return;
  tracker->tracker.SetDebug(enable != 0);
}
