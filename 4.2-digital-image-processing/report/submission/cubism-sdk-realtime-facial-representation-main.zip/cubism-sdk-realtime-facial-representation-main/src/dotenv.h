#ifndef __RFR_DOTENV_H__
#define __RFR_DOTENV_H__
#pragma once

char *trim(char *str);

/**
 * Loads environment variables from a .env file.
 * @param filepath Path to the .env file.
 * @return 0 on success, -1 on failure.
 */
int load_dotenv(const char *filepath);

#endif  //__RFR_DOTENV_H__
