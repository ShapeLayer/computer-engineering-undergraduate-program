#ifndef __RFR_CUBISM_BRIDGE_H__
#define __RFR_CUBISM_BRIDGE_H__
#pragma once

#include "face_state.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct CubismBridge CubismBridge;

CubismBridge *cubism_bridge_create(const char *moc3_path);
void cubism_bridge_destroy(CubismBridge *bridge);

void cubism_bridge_resize(CubismBridge *bridge, int width, int height);
void cubism_bridge_update(CubismBridge *bridge, float delta_seconds);
void cubism_bridge_draw(CubismBridge *bridge);
void cubism_bridge_apply_face_state(CubismBridge *bridge, const FaceStateC *state);
void cubism_bridge_set_view(CubismBridge *bridge, float pan_x, float pan_y, float scale);

#ifdef __cplusplus
}
#endif
#endif  //__RFR_CUBISM_BRIDGE_H__
