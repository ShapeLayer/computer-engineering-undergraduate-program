#include "dotenv.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *trim(char *str)
{
  char *end;

  while (isspace((unsigned char)*str))
    str++;

  if (*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while (end > str && isspace((unsigned char)*end))
    end--;

  end[1] = '\0';

  return str;
}

int load_dotenv(const char *filename)
{
  FILE *fp = fopen(filename, "r");
  if (fp == NULL)
  {
    perror("Cannot open .env file");
    return -1;
  }

  char line[1024];
  while (fgets(line, sizeof(line), fp))
  {
    // Remove comments
    char *comment = strchr(line, '#');
    if (comment)
      *comment = '\0';

    // Trim whitespace
    char *trimmed_line = trim(line);

    if (strlen(trimmed_line) == 0)
      continue;

    char *delimiter = strchr(trimmed_line, '=');
    if (delimiter == NULL)
      continue;

    *delimiter = '\0';
    char *key = trim(trimmed_line);
    char *value = trim(delimiter + 1);

    if (setenv(key, value, 1) != 0)
    {
      perror("Failed to set environment variable");
      fclose(fp);
      return -1;
    }
  }

  fclose(fp);
  return 0;
}
