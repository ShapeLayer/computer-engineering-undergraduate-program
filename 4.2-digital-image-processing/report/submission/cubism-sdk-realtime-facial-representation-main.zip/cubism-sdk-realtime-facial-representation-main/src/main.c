#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include "cubism_bridge.h"
#include "face_tracker_c.h"
#include "dotenv.h"

static void glfw_error_callback(int code, const char *desc)
{
  fprintf(stderr, "[GLFW] %d: %s\n", code, desc);
}

typedef struct PanState
{
  int mode;
  int lastX;
  int lastY;
  int curX;
  int curY;
  float zoom;
} PanState;

static void mouse_button_callback(GLFWwindow *w, int button, int action, int mods)
{
  double x = 0.0, y = 0.0;
  glfwGetCursorPos(w, &x, &y);
  PanState *state = (PanState *)glfwGetWindowUserPointer(w);
  if (!state)
    return;
  if (button == GLFW_MOUSE_BUTTON_MIDDLE)
  {
    state->mode = (action == GLFW_PRESS) ? 1 : 0;
    if (action == GLFW_PRESS)
    {
      state->lastX = (int)x;
      state->lastY = (int)y;
      state->curX = state->lastX;
      state->curY = state->lastY;
    }
  }
  if (button == GLFW_MOUSE_BUTTON_LEFT && (mods & GLFW_MOD_ALT))
  {
    state->mode = (action == GLFW_PRESS) ? 2 : 0;
    if (action == GLFW_PRESS)
    {
      state->lastX = (int)x;
      state->lastY = (int)y;
      state->curX = state->lastX;
      state->curY = state->lastY;
    }
  }
}

static void cursor_pos_callback(GLFWwindow *w, double xpos, double ypos)
{
  PanState *state = (PanState *)glfwGetWindowUserPointer(w);
  if (!state || state->mode == 0)
    return;
  state->curX = (int)xpos;
  state->curY = (int)ypos;
}

static void scroll_callback(GLFWwindow *w, double, double yoffset)
{
  PanState *state = (PanState *)glfwGetWindowUserPointer(w);
  if (!state)
    return;
  const float step = 1.1f;
  if (yoffset > 0.0)
    state->zoom *= step;
  else if (yoffset < 0.0)
    state->zoom /= step;
  if (state->zoom < 0.1f)
    state->zoom = 0.1f;
  if (state->zoom > 5.0f)
    state->zoom = 5.0f;
}

static GLuint compile_shader(GLenum type, const char *src)
{
  GLuint shader = glCreateShader(type);
  glShaderSource(shader, 1, &src, NULL);
  glCompileShader(shader);
  GLint ok = 0;
  glGetShaderiv(shader, GL_COMPILE_STATUS, &ok);
  if (!ok)
  {
    char log[1024];
    glGetShaderInfoLog(shader, sizeof(log), NULL, log);
    fprintf(stderr, "[GL] Shader compile error: %s\n", log);
  }
  return shader;
}

static GLuint create_program(const char *vs, const char *fs)
{
  GLuint v = compile_shader(GL_VERTEX_SHADER, vs);
  GLuint f = compile_shader(GL_FRAGMENT_SHADER, fs);
  GLuint p = glCreateProgram();
  glAttachShader(p, v);
  glAttachShader(p, f);
  glLinkProgram(p);
  GLint ok = 0;
  glGetProgramiv(p, GL_LINK_STATUS, &ok);
  if (!ok)
  {
    char log[1024];
    glGetProgramInfoLog(p, sizeof(log), NULL, log);
    fprintf(stderr, "[GL] Program link error: %s\n", log);
  }
  glDeleteShader(v);
  glDeleteShader(f);
  return p;
}

typedef struct Offscreen
{
  GLuint fbo;
  GLuint colorTex;
  GLuint depthStencilRbo;
  GLuint quadVbo;
  GLuint quadProgram;
  GLint quadPosLoc;
  GLint quadUvLoc;
  int width;
  int height;
} Offscreen;

static void offscreen_init(Offscreen *o)
{
  memset(o, 0, sizeof(*o));
  const char *vs = "#version 120\n"
                   "attribute vec2 aPos;\n"
                   "attribute vec2 aUV;\n"
                   "varying vec2 vUV;\n"
                   "void main(){ vUV=aUV; gl_Position=vec4(aPos,0.0,1.0); }\n";
  const char *fs = "#version 120\n"
                   "varying vec2 vUV;\n"
                   "uniform sampler2D uTex;\n"
                   "void main(){ gl_FragColor=texture2D(uTex,vUV); }\n";
  o->quadProgram = create_program(vs, fs);
  o->quadPosLoc = o->quadProgram ? glGetAttribLocation(o->quadProgram, "aPos") : -1;
  o->quadUvLoc = o->quadProgram ? glGetAttribLocation(o->quadProgram, "aUV") : -1;

  float quadVerts[] = {
      -1.0f, -1.0f, 0.0f, 0.0f,
      1.0f, -1.0f, 1.0f, 0.0f,
      1.0f, 1.0f, 1.0f, 1.0f,
      -1.0f, -1.0f, 0.0f, 0.0f,
      1.0f, 1.0f, 1.0f, 1.0f,
      -1.0f, 1.0f, 0.0f, 1.0f};

  glGenBuffers(1, &o->quadVbo);
  glBindBuffer(GL_ARRAY_BUFFER, o->quadVbo);
  glBufferData(GL_ARRAY_BUFFER, sizeof(quadVerts), quadVerts, GL_STATIC_DRAW);
  glBindBuffer(GL_ARRAY_BUFFER, 0);
}

static void offscreen_resize(Offscreen *o, int width, int height)
{
  if (o->width == width && o->height == height && o->fbo != 0)
    return;

  o->width = width;
  o->height = height;

  if (o->fbo)
  {
    glDeleteFramebuffers(1, &o->fbo);
    glDeleteTextures(1, &o->colorTex);
    glDeleteRenderbuffers(1, &o->depthStencilRbo);
  }

  glGenFramebuffers(1, &o->fbo);
  glBindFramebuffer(GL_FRAMEBUFFER, o->fbo);

  glGenTextures(1, &o->colorTex);
  glBindTexture(GL_TEXTURE_2D, o->colorTex);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
  glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, o->colorTex, 0);

  glGenRenderbuffers(1, &o->depthStencilRbo);
  glBindRenderbuffer(GL_RENDERBUFFER, o->depthStencilRbo);
  glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, width, height);
  glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, o->depthStencilRbo);

  GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
  if (status != GL_FRAMEBUFFER_COMPLETE)
  {
    fprintf(stderr, "[GL] FBO incomplete: 0x%x\n", status);
  }

  glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

static void offscreen_draw(Offscreen *o)
{
  if (!o->quadProgram)
    return;
  glUseProgram(o->quadProgram);
  glActiveTexture(GL_TEXTURE0);
  glBindTexture(GL_TEXTURE_2D, o->colorTex);
  glUniform1i(glGetUniformLocation(o->quadProgram, "uTex"), 0);
  glBindBuffer(GL_ARRAY_BUFFER, o->quadVbo);
  if (o->quadPosLoc >= 0)
  {
    glEnableVertexAttribArray((GLuint)o->quadPosLoc);
    glVertexAttribPointer((GLuint)o->quadPosLoc, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void *)0);
  }
  if (o->quadUvLoc >= 0)
  {
    glEnableVertexAttribArray((GLuint)o->quadUvLoc);
    glVertexAttribPointer((GLuint)o->quadUvLoc, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void *)(2 * sizeof(float)));
  }
  glDrawArrays(GL_TRIANGLES, 0, 6);
  if (o->quadPosLoc >= 0) glDisableVertexAttribArray((GLuint)o->quadPosLoc);
  if (o->quadUvLoc >= 0) glDisableVertexAttribArray((GLuint)o->quadUvLoc);
  glBindBuffer(GL_ARRAY_BUFFER, 0);
}

static int is_dir(const char *path)
{
  struct stat st;
  if (stat(path, &st) != 0)
    return 0;
  return S_ISDIR(st.st_mode);
}

static int file_exists(const char *path)
{
  struct stat st;
  return (stat(path, &st) == 0) && S_ISREG(st.st_mode);
}

static void join_path(char *out, size_t out_size, const char *a, const char *b)
{
  if (!a || !a[0])
  {
    snprintf(out, out_size, "%s", b ? b : "");
    return;
  }
  if (!b || !b[0])
  {
    snprintf(out, out_size, "%s", a);
    return;
  }
  const size_t alen = strlen(a);
  if (a[alen - 1] == '/' || a[alen - 1] == '\\')
    snprintf(out, out_size, "%s%s", a, b);
  else
    snprintf(out, out_size, "%s/%s", a, b);
}

static int resolve_env_file(const char *argv0, char *out, size_t out_size)
{
  if (file_exists(".env"))
  {
    snprintf(out, out_size, ".env");
    return 1;
  }

  char cwd[1024];
  if (getcwd(cwd, sizeof(cwd)))
  {
    const char *candidates[] = {"../.env", "../../.env", "../../../.env"};
    for (size_t i = 0; i < sizeof(candidates) / sizeof(candidates[0]); ++i)
    {
      char tmp[1024];
      join_path(tmp, sizeof(tmp), cwd, candidates[i]);
      if (file_exists(tmp))
      {
        snprintf(out, out_size, "%s", tmp);
        return 1;
      }
    }
  }

  if (argv0 && strchr(argv0, '/'))
  {
    char exe_dir[1024];
    snprintf(exe_dir, sizeof(exe_dir), "%s", argv0);
    char *slash = strrchr(exe_dir, '/');
    if (slash)
    {
      *slash = '\0';
      const char *candidates[] = {".env", "../.env", "../../.env"};
      for (size_t i = 0; i < sizeof(candidates) / sizeof(candidates[0]); ++i)
      {
        char tmp[1024];
        join_path(tmp, sizeof(tmp), exe_dir, candidates[i]);
        if (file_exists(tmp))
        {
          snprintf(out, out_size, "%s", tmp);
          return 1;
        }
      }
    }
  }

  return 0;
}

static int is_abs_path(const char *path)
{
  return path && path[0] == '/';
}

static void dirname_from_path(const char *path, char *out, size_t out_size)
{
  if (!path || !path[0])
  {
    snprintf(out, out_size, ".");
    return;
  }
  snprintf(out, out_size, "%s", path);
  char *slash = strrchr(out, '/');
  if (slash)
    *slash = '\0';
  else
    snprintf(out, out_size, ".");
}

static const char *resolve_env_relative_path(const char *envDir,
                                             const char *value,
                                             char *out,
                                             size_t out_size)
{
  if (!value || !value[0])
    return value;
  if (is_abs_path(value))
    return value;
  if (!envDir || !envDir[0])
    return value;
  join_path(out, out_size, envDir, value);
  return out;
}

static int parse_bg_color(const char *text, float *outR, float *outG, float *outB, float *outA)
{
  if (!text || !text[0])
    return 0;

  if (text[0] == '#')
  {
    unsigned int hex = 0;
    const size_t len = strlen(text + 1);
    if (len != 6 && len != 8)
      return 0;
    if (sscanf(text + 1, "%x", &hex) != 1)
      return 0;
    if (len == 6)
    {
      *outR = ((hex >> 16) & 0xFF) / 255.0f;
      *outG = ((hex >> 8) & 0xFF) / 255.0f;
      *outB = (hex & 0xFF) / 255.0f;
      *outA = 1.0f;
      return 1;
    }
    *outR = ((hex >> 24) & 0xFF) / 255.0f;
    *outG = ((hex >> 16) & 0xFF) / 255.0f;
    *outB = ((hex >> 8) & 0xFF) / 255.0f;
    *outA = (hex & 0xFF) / 255.0f;
    return 1;
  }

  if (strncmp(text, "0x", 2) == 0 || strncmp(text, "0X", 2) == 0)
  {
    unsigned int hex = 0;
    if (sscanf(text + 2, "%x", &hex) != 1)
      return 0;
    if (strlen(text + 2) <= 6)
    {
      *outR = ((hex >> 16) & 0xFF) / 255.0f;
      *outG = ((hex >> 8) & 0xFF) / 255.0f;
      *outB = (hex & 0xFF) / 255.0f;
      *outA = 1.0f;
      return 1;
    }
    *outR = ((hex >> 24) & 0xFF) / 255.0f;
    *outG = ((hex >> 16) & 0xFF) / 255.0f;
    *outB = ((hex >> 8) & 0xFF) / 255.0f;
    *outA = (hex & 0xFF) / 255.0f;
    return 1;
  }

  char buf[128];
  snprintf(buf, sizeof(buf), "%s", text);
  float values[4] = {0, 0, 0, 1};
  int count = 0;
  char *save = NULL;
  char *tok = strtok_r(buf, ",", &save);
  while (tok && count < 4)
  {
    values[count++] = (float)atof(tok);
    tok = strtok_r(NULL, ",", &save);
  }
  if (count < 3)
    return 0;

  float scale = 1.0f;
  for (int i = 0; i < count; ++i)
  {
    if (values[i] > 1.0f)
    {
      scale = 1.0f / 255.0f;
      break;
    }
  }

  *outR = values[0] * scale;
  *outG = values[1] * scale;
  *outB = values[2] * scale;
  *outA = (count >= 4) ? values[3] * scale : 1.0f;
  return 1;
}

static int try_set_dir(const char *path, char *out, size_t out_size)
{
  if (!path || !path[0])
    return 0;
  snprintf(out, out_size, "%s", path);
  return is_dir(out);
}

static void resolve_cascade_dir(const char *argv0, const char *input, char *out, size_t out_size)
{
  if (try_set_dir(input, out, out_size))
    return;

  char cwd[1024];
  if (getcwd(cwd, sizeof(cwd)))
  {
    const char *candidates[] = {
        "external/haarcascades",
        "../external/haarcascades",
        "../../external/haarcascades",
        "../lite2d/include/haarcascades",
        "../../lite2d/include/haarcascades",
    };
    for (size_t i = 0; i < sizeof(candidates) / sizeof(candidates[0]); ++i)
    {
      join_path(out, out_size, cwd, candidates[i]);
      if (is_dir(out))
        return;
    }
  }

  if (argv0 && strchr(argv0, '/'))
  {
    char exe_dir[1024];
    snprintf(exe_dir, sizeof(exe_dir), "%s", argv0);
    char *slash = strrchr(exe_dir, '/');
    if (slash)
    {
      *slash = '\0';
      const char *candidates[] = {
          "external/haarcascades",
          "../external/haarcascades",
          "../../external/haarcascades",
          "../lite2d/include/haarcascades",
          "../../lite2d/include/haarcascades",
      };
      for (size_t i = 0; i < sizeof(candidates) / sizeof(candidates[0]); ++i)
      {
        join_path(out, out_size, exe_dir, candidates[i]);
        if (is_dir(out))
          return;
      }
    }
  }

  snprintf(out, out_size, "%s", input && input[0] ? input : "external/haarcascades");
}

int main(int argc, char **argv)
{
  const char *moc3Path = NULL;
#ifdef CUBISM_DEFAULT_CASCADE_DIR
  const char *cascadeDir = CUBISM_DEFAULT_CASCADE_DIR;
#else
  const char *cascadeDir = "external/haarcascades";
#endif
  const char *dnnProto = NULL;
  const char *dnnModel = NULL;
  int cameraIndex = 0;
  int debugCamera = 0;
  float panX = 0.0f;
  float panY = 0.0f;
  float bgR = 0.1f;
  float bgG = 0.1f;
  float bgB = 0.12f;
  float bgA = 1.0f;
  int panning = 0;
  double lastX = 0.0;
  double lastY = 0.0;

  char envPath[1024];
  char envDir[1024] = {0};
  if (resolve_env_file(argv[0], envPath, sizeof(envPath)))
  {
    load_dotenv(envPath);
    dirname_from_path(envPath, envDir, sizeof(envDir));
  }

  const char *envModel = getenv("MODEL_PATH");
  const char *envCamera = getenv("CAMERA_INDEX");
  const char *envDebug = getenv("ENABLE_DEBUG_VIEWER");
  const char *envCascade = getenv("CASCADE_DIR");
  const char *envDnnProto = getenv("DNN_PROTO");
  const char *envDnnModel = getenv("DNN_MODEL");
  const char *envBg = getenv("BG_COLOR");

  char resolvedModel[1024];
  char resolvedCascade[1024];
  char resolvedDnnProto[1024];
  char resolvedDnnModel[1024];

  if (envModel && envModel[0])
    moc3Path = resolve_env_relative_path(envDir, envModel, resolvedModel, sizeof(resolvedModel));
  if (envCamera && envCamera[0])
    cameraIndex = atoi(envCamera);
  if (envDebug && envDebug[0])
    debugCamera = atoi(envDebug) ? 1 : 0;
  if (envCascade && envCascade[0])
    cascadeDir = resolve_env_relative_path(envDir, envCascade, resolvedCascade, sizeof(resolvedCascade));
  if (envDnnProto && envDnnProto[0])
    dnnProto = resolve_env_relative_path(envDir, envDnnProto, resolvedDnnProto, sizeof(resolvedDnnProto));
  if (envDnnModel && envDnnModel[0])
    dnnModel = resolve_env_relative_path(envDir, envDnnModel, resolvedDnnModel, sizeof(resolvedDnnModel));
  if (envBg && envBg[0])
    parse_bg_color(envBg, &bgR, &bgG, &bgB, &bgA);

  for (int i = 1; i < argc; ++i)
  {
    const char *arg = argv[i];
    if (strcmp(arg, "-h") == 0 || strcmp(arg, "--help") == 0)
    {
      fprintf(stderr, "Usage: %s /path/to/model.moc3 [options]\n", argv[0]);
      fprintf(stderr, "Options:\n");
      fprintf(stderr, "  -c, --cascade=DIR     Cascade directory (default: external/haarcascades)\n");
      fprintf(stderr, "  -i, --camera=INDEX    Camera index (default: 0)\n");
      fprintf(stderr, "  --dnn-proto=FILE      DNN deploy.prototxt\n");
      fprintf(stderr, "  --dnn-model=FILE      DNN caffemodel\n");
      fprintf(stderr, "  -b, --bg-color=COLOR  Background color (#RRGGBB[AA] or r,g,b[,a])\n");
      fprintf(stderr, "  -d, --debug-camera    Enable debug camera window\n");
      return 0;
    }

    if (strncmp(arg, "--cascade=", 10) == 0)
    {
      cascadeDir = arg + 10;
      continue;
    }
    if (strncmp(arg, "--camera=", 9) == 0)
    {
      cameraIndex = atoi(arg + 9);
      continue;
    }
    if (strncmp(arg, "--dnn-proto=", 12) == 0)
    {
      dnnProto = arg + 12;
      continue;
    }
    if (strncmp(arg, "--dnn-model=", 12) == 0)
    {
      dnnModel = arg + 12;
      continue;
    }
    if (strncmp(arg, "--bg-color=", 11) == 0)
    {
      parse_bg_color(arg + 11, &bgR, &bgG, &bgB, &bgA);
      continue;
    }
    if (strncmp(arg, "--bg=", 5) == 0)
    {
      parse_bg_color(arg + 5, &bgR, &bgG, &bgB, &bgA);
      continue;
    }
    if (strcmp(arg, "--debug-camera") == 0)
    {
      debugCamera = 1;
      continue;
    }

    if ((strcmp(arg, "-c") == 0 || strcmp(arg, "--cascade") == 0))
    {
      if (i + 1 >= argc)
      {
        fprintf(stderr, "Missing value for %s\n", arg);
        return 1;
      }
      cascadeDir = argv[++i];
      continue;
    }
    if (strncmp(arg, "-c=", 3) == 0)
    {
      cascadeDir = arg + 3;
      continue;
    }

    if ((strcmp(arg, "-i") == 0 || strcmp(arg, "--camera") == 0))
    {
      if (i + 1 >= argc)
      {
        fprintf(stderr, "Missing value for %s\n", arg);
        return 1;
      }
      cameraIndex = atoi(argv[++i]);
      continue;
    }
    if (strncmp(arg, "-i=", 3) == 0)
    {
      cameraIndex = atoi(arg + 3);
      continue;
    }

    if (strcmp(arg, "--dnn-proto") == 0)
    {
      if (i + 1 >= argc)
      {
        fprintf(stderr, "Missing value for %s\n", arg);
        return 1;
      }
      dnnProto = argv[++i];
      continue;
    }
    if (strcmp(arg, "--dnn-model") == 0)
    {
      if (i + 1 >= argc)
      {
        fprintf(stderr, "Missing value for %s\n", arg);
        return 1;
      }
      dnnModel = argv[++i];
      continue;
    }

    if (strcmp(arg, "--bg-color") == 0 || strcmp(arg, "--bg") == 0 || strcmp(arg, "-b") == 0)
    {
      if (i + 1 >= argc)
      {
        fprintf(stderr, "Missing value for %s\n", arg);
        return 1;
      }
      parse_bg_color(argv[++i], &bgR, &bgG, &bgB, &bgA);
      continue;
    }

    if (strncmp(arg, "-b=", 3) == 0)
    {
      parse_bg_color(arg + 3, &bgR, &bgG, &bgB, &bgA);
      continue;
    }

    if (strcmp(arg, "-d") == 0)
    {
      debugCamera = 1;
      continue;
    }

    if (arg[0] == '-')
    {
      fprintf(stderr, "Unknown option: %s\n", arg);
      return 1;
    }

    if (!moc3Path)
    {
      moc3Path = arg;
      continue;
    }

    fprintf(stderr, "Unexpected argument: %s\n", arg);
    return 1;
  }

  if (!moc3Path)
  {
    if (envModel && envModel[0] == '\0')
    {
      fprintf(stderr, "MODEL_PATH is empty in .env\n");
      return 1;
    }
    fprintf(stderr, "Usage: %s /path/to/model.moc3 [options]\n", argv[0]);
    return 1;
  }

  glfwSetErrorCallback(glfw_error_callback);
  if (!glfwInit())
  {
    fprintf(stderr, "Failed to init GLFW\n");
    return 1;
  }

  glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
  glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);
  glfwWindowHint(GLFW_STENCIL_BITS, 8);
#ifndef __APPLE__
  glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_ANY_PROFILE);
#endif

  GLFWwindow *window = glfwCreateWindow(1280, 720, "Cubism VTuber", NULL, NULL);
  if (!window)
  {
    fprintf(stderr, "Failed to create window\n");
    glfwTerminate();
    return 1;
  }

  glfwMakeContextCurrent(window);
  glfwSwapInterval(1);

  glfwSetMouseButtonCallback(window, mouse_button_callback);
  glfwSetScrollCallback(window, scroll_callback);
  glfwSetCursorPosCallback(window, cursor_pos_callback);

  GLenum glewErr = glewInit();
  if (glewErr != GLEW_OK)
  {
    fprintf(stderr, "GLEW init failed: %s\n", glewGetErrorString(glewErr));
    glfwDestroyWindow(window);
    glfwTerminate();
    return 1;
  }

  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_CULL_FACE);

  GLint stencilBits = 0;
  glGetIntegerv(GL_STENCIL_BITS, &stencilBits);
  fprintf(stderr, "[GL] Stencil bits: %d\n", stencilBits);

  fprintf(stderr, "[GL] Version: %s\n", glGetString(GL_VERSION));
  fprintf(stderr, "[GL] GLSL: %s\n", glGetString(GL_SHADING_LANGUAGE_VERSION));

  char cwd_buf[1024];
  const char *cwd_ptr = getcwd(cwd_buf, sizeof(cwd_buf)) ? cwd_buf : "?";
  if (!file_exists("FrameworkShaders/VertShaderSrc.vert") &&
      !file_exists("build/FrameworkShaders/VertShaderSrc.vert"))
  {
    fprintf(stderr, "[Cubism] Missing shader: FrameworkShaders/VertShaderSrc.vert (cwd=%s)\n", cwd_ptr);
  }
  if (!file_exists("FrameworkShaders/FragShaderSrc.frag") &&
      !file_exists("build/FrameworkShaders/FragShaderSrc.frag"))
  {
    fprintf(stderr, "[Cubism] Missing shader: FrameworkShaders/FragShaderSrc.frag (cwd=%s)\n", cwd_ptr);
  }

  Offscreen offscreen;
  offscreen_init(&offscreen);

  CubismBridge *bridge = cubism_bridge_create(moc3Path);
  if (!bridge)
  {
    fprintf(stderr, "Failed to load Cubism model: %s\n", moc3Path);
    glfwDestroyWindow(window);
    glfwTerminate();
    return 1;
  }

  FaceTrackerC *tracker = NULL;
  char cascadeResolved[1024];
  resolve_cascade_dir(argv[0], cascadeDir, cascadeResolved, sizeof(cascadeResolved));
  if (cascadeResolved[0] != '\0')
  {
    if (dnnProto && dnnModel)
      tracker = face_tracker_create_ex(cascadeResolved, cameraIndex, dnnProto, dnnModel);
    else
      tracker = face_tracker_create(cascadeResolved, cameraIndex);
    if (!tracker)
    {
      fprintf(stderr, "Failed to init face tracker. Check cascade_dir and camera_index.\n");
      fprintf(stderr, "Tried cascade_dir: %s\n", cascadeResolved);
    }
    else
    {
      face_tracker_set_debug(tracker, debugCamera);
    }
  }

  PanState panState = {0, 0, 0, 0, 0, 1.0f};
  glfwSetWindowUserPointer(window, &panState);

  double lastTime = glfwGetTime();
  while (!glfwWindowShouldClose(window))
  {
    double now = glfwGetTime();
    double dt = now - lastTime;
    lastTime = now;
    int width = 0, height = 0;
    glfwGetFramebufferSize(window, &width, &height);
    offscreen_resize(&offscreen, width, height);

    glBindFramebuffer(GL_FRAMEBUFFER, offscreen.fbo);
    glViewport(0, 0, width, height);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

    cubism_bridge_resize(bridge, width, height);

    if (panState.mode != 0)
    {
      const int dx = panState.curX - panState.lastX;
      const int dy = panState.curY - panState.lastY;
      panState.lastX = panState.curX;
      panState.lastY = panState.curY;
      const float scale = (height > 0) ? (2.0f / (float)height) : 0.002f;
      panX += dx * scale;
      panY -= dy * scale;
    }
    cubism_bridge_set_view(bridge, panX, panY, panState.zoom);

    if (tracker)
    {
      FaceStateC face;
      face_tracker_update(tracker, dt, &face);
      cubism_bridge_apply_face_state(bridge, &face);
    }

    cubism_bridge_update(bridge, 0.0f);
    cubism_bridge_draw(bridge);

    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, width, height);
    glClearColor(bgR, bgG, bgB, bgA);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
    offscreen_draw(&offscreen);

    glfwSwapBuffers(window);
    glfwPollEvents();
  }

  if (tracker)
  {
    face_tracker_destroy(tracker);
  }
  cubism_bridge_destroy(bridge);
  glfwDestroyWindow(window);
  glfwTerminate();
  return 0;
}
