# cubism_vtuber

## Requirements
- CubismNativeFramework (Download from [Live2D Cubism SDK](https://www.live2d.com/en/sdk/about/) and place in [`./external/CubismNativeFramework`](./external/))
- OpenGL, GLFW, GLEW
- OpenCV (for webcam face tracking)

## Getting Started

```sh
mkdir build
cd build
cmake ..
make
```

Complete model setup, or refer [`live2d-models-json-converted/mao_pro_json/mao_pro/README.md`](./live2d-models-json-converted/mao_pro_json/mao_pro/README.md) for examples.

Use `.env` file to set default model path and options, or pass them as command line arguments.

## Usage
Pass a .moc3/.moc3.json path, options are accepted with - or --. Cascades default to external/haarcascades.

Options:  
-c, --cascade=DIR     Cascade directory (default: external/haarcascades)  
-i, --camera=INDEX    Camera index (default: 0)  
-d, --debug-camera    Enable debug camera window  
