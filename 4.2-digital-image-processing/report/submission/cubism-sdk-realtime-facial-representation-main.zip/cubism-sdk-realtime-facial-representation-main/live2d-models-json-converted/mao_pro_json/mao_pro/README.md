# Mao Pro Index Definition (JSON)

This model data defines the atlas index of the Mao Pro Live2D model in JSON format. It was created using the `moc32json` and `lite2d-editor` tools from the [ShapeLayer/lite2d](https://github.com/shapelayer/lite2d) repository. 

Please note that this data does not directly include the model's atlas (PNG) files. You must download the PRO version of the Niziiro Mao model from the [Live2D Sample Data (for Free)](https://www.live2d.com/en/learn/sample/) page to obtain the necessary atlas files. The atlas file should be placed at the following path: [`./mao_pro.4096/texture_00.png`](./mao_pro.4096) (A placeholder file is currently located there).
